module.exports = {
    bot: {
        prefixe: '+', // Préfixe - Le texte avant les commandes
        buyer: '1341385559687565354', // Buyer
        couleur: '#6495ED', // Couleur HEX
        footer: 'Zprotect', // Dans la commande help ou autre il y'a un texte en bas
        maxServer: '100', // Le nombre de serveur maximum que le bot peut rejoindre 
    }
}
