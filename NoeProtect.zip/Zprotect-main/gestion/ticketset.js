const { MessageActionRow, MessageSelectMenu } = require('discord.js')
const config = require('../config')
const db = require('quick.db')
const owner = new db.table("Owner")
const cl = new db.table("Color")
const p = new db.table("Prefix")

module.exports = {
    name: 'ticketset',
    usage: 'ticketset',
    category: "owner",
    description: `Commande ticket set.`,
    async execute(client, message, args) {

        if (owner.get(`owners.${message.author.id}`) || config.bot.buyer.includes(message.author.id)   === true) {

            let color = cl.fetch(`color_${message.guild.id}`)
            if (color == null) color = config.bot.couleur

            let pf = p.fetch(`prefix_${message.guild.id}`)
            if (pf == null) pf = config.prefix

            message.delete()
            const row = new MessageActionRow()
                .addComponents(
                    new MessageSelectMenu()
                        .setCustomId('select')
                        .setPlaceholder(`Cliquez pour ouvrir un ticket`)
                        .addOptions([
                            {
                                label: 'Ticket',
                                emoji: '998562005155860510',
                                description: `Cliquez ici si vous souhaitez ouvrir un ticket`,
                                value: 'open',
                            },
                            {
                                label: 'Annuler',
                                emoji: '988389407730040863',
                                description: "Annuler l'action",
                                value: 'rien',
                            },
                        ])
                );

            message.channel.send({
                embeds: [{
                    title: `__Support ${message.guild.name}__`,
                    description: `**Pour ouvrir un Ticket cliquez sur l'un des menus ci-dessous et choisissez l'option qui correspond à votre demande**`,
                    color: color,
                    footer: { text: `Tout troll pourra être sanctionné d'un bannissement` }
                }],
                components: [row]
            })
        }
    }
}